module led_spead (
    input  logic       clk,
    input  logic       rst,
    input  logic       done,
    input  logic [7:0] d_in,
    output logic [9:0] d_out
);
    logic [7:0] d_in_reg;
    logic [6:0] mux_in;

    //step1
    always_ff @(posedge clk or posedge rst) begin
        if (rst) begin
            d_in_reg <= 0;
        end else begin
            d_in_reg <= d_in;
        end
    end
    //step2
    assign mux_in = d_in_reg / 10;
    //step3
    always_comb begin
        case (mux_in)
            0:       d_out = 10'd0;
            1:       d_out = 10'd1;
            2:       d_out = 10'd3;
            3:       d_out = 10'd7;
            4:       d_out = 10'd15;
            5:       d_out = 10'd31;
            6:       d_out = 10'd63;
            7:       d_out = 10'd127;
            8:       d_out = 10'd255;
            9:       d_out = 10'd511;
            10:      d_out = 10'd1023;
            default: d_out = 10'd0;
        endcase
    end
endmodule
